﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Vinaits.Controllers
{
    public class ServiceController : Controller
    {
        // GET: Service
        public ActionResult Service_List()
        {
            return View();
        }
        public ActionResult Service_first()
        {
            return View();
        }
        public ActionResult Service_second()
        {
            return View();
        }
        public ActionResult Service_third()
        {
            return View();
        }
    }
}