﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Vinaits.Models;

namespace Vinaits.Controllers
{
    public class DetailController : Controller
    {
        // GET: Detail
        Model_Vinaits db = new Model_Vinaits();
        [HttpGet]
        public ActionResult Detail_Page(int id)
        {
            var news = (from r in db.db_content
                        where r.id_menu==id
                         select r).ToList<tbl_content>();

            tbl_menu cd = db.db_menu.SingleOrDefault(n => n.id == id);
      
            ViewBag.title_catagory = cd.list_name;
            return View(news);
        }

        public ActionResult Detail_Content_Page(int id)
        {
            tbl_content cd = db.db_content.SingleOrDefault(n => n.id == id);
            return View(cd);
        }
    }
}