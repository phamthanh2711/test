﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Vinaits.Models;

namespace Vinaits.Controllers
{
    public class MenuController : Controller
    {
        // GET: Menu
        Model_Vinaits db = new Model_Vinaits();
        public ActionResult Menu_Partial()
        {
            return View();
        }
            
    }
}