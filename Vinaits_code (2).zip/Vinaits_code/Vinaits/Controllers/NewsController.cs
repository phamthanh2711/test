﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Vinaits.Controllers
{
    public class NewsController : Controller
    {
        // GET: News
        public ActionResult News_List()
        {
            return View();
        }
        public ActionResult News_first()
        {
            return View();
        }
        public ActionResult News_second()
        {
            return View();
        }
        public ActionResult News_third()
        {
            return View();
        }
    }
}