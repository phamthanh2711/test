﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Vinaits.Models;

namespace Vinaits.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        Model_Vinaits db = new Model_Vinaits();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Introduct()
        {
            return View();
        }
        public ActionResult Service()
        {
            return View();
        }
        public ActionResult Employ()
        {
            return View();
        }
        public ActionResult News()
        {
            return View();
        }
        public ActionResult Contact()
        {
            return View();
        }
    }
}