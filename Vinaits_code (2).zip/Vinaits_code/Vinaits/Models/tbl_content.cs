namespace Vinaits.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class tbl_content
    {
        public int id { get; set; }

        [StringLength(200)]
        public string title { get; set; }

        [Column(TypeName = "ntext")]
        public string content_detail { get; set; }

        [StringLength(500)]
        public string summary { get; set; }

        [Column(TypeName = "ntext")]
        public string image { get; set; }

        [StringLength(100)]
        public string date_post { get; set; }

        public int? id_menu { get; set; }
    }
}
