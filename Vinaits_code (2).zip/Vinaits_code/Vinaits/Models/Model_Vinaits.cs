namespace Vinaits.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Model_Vinaits : DbContext
    {
        public Model_Vinaits()
            : base("name=Model_Vinaits")
        {
        }

        public virtual DbSet<tbl_content> db_content { get; set; }
        public virtual DbSet<tbl_menu> db_menu { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {

        }
    }
}
